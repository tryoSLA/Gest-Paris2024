CREATE VIEW athlete_detaille AS
  SELECT
    `paris_2024`.`personne`.`Nom`        AS `Nom`,
    `paris_2024`.`personne`.`Prenom`     AS `Prenom`,
    `paris_2024`.`personne`.`Age`        AS `Age`,
    `paris_2024`.`personne`.`Genre`      AS `Genre`,
    `paris_2024`.`pays`.`Libelle_pays`   AS `Libelle_pays`,
    `paris_2024`.`athlete`.`Photo`       AS `Photo`,
    `paris_2024`.`athlete`.`Biographie`  AS `Biographie`,
    `paris_2024`.`athlete`.`Poids`       AS `Poids`,
    `paris_2024`.`athlete`.`Taille`      AS `Taille`,
    `paris_2024`.`sport`.`Libelle_sport` AS `Libelle_sport`
  FROM `paris_2024`.`personne`
    JOIN `paris_2024`.`athlete`
    JOIN `paris_2024`.`sport`
    JOIN `paris_2024`.`pays`
  WHERE ((`paris_2024`.`sport`.`id_sport` = `paris_2024`.`athlete`.`id_sport`) AND
         (`paris_2024`.`pays`.`id_pays` = `paris_2024`.`athlete`.`id_pays`) AND
         (`paris_2024`.`personne`.`id_personne` = `paris_2024`.`athlete`.`id_personne`));

