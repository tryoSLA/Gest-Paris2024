CREATE VIEW vue_rss AS
  SELECT
    `paris_2024`.`fluxrss`.`Rss`         AS `Rss`,
    `paris_2024`.`fluxrss`.`Lien`        AS `Lien`,
    `paris_2024`.`fluxrss`.`Titre`       AS `Titre`,
    `paris_2024`.`fluxrss`.`Description` AS `Description`,
    `paris_2024`.`fluxrss`.`Date`        AS `Date`
  FROM `paris_2024`.`fluxrss`
  ORDER BY `paris_2024`.`fluxrss`.`Date` DESC;

