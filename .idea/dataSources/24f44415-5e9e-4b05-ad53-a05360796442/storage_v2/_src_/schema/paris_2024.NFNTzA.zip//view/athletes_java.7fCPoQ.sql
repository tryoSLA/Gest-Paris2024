CREATE VIEW athletes_java AS
  SELECT
    `paris_2024`.`personne`.`id_personne` AS `id_personne`,
    `paris_2024`.`personne`.`Nom`         AS `Nom`,
    `paris_2024`.`personne`.`Prenom`      AS `Prenom`,
    `paris_2024`.`personne`.`Age`         AS `Age`,
    `paris_2024`.`personne`.`Genre`       AS `Genre`,
    `paris_2024`.`athlete`.`Photo`        AS `Photo`,
    `paris_2024`.`athlete`.`Biographie`   AS `Biographie`,
    `paris_2024`.`athlete`.`Poids`        AS `Poids`,
    `paris_2024`.`athlete`.`Taille`       AS `Taille`,
    `paris_2024`.`athlete`.`id_sport`     AS `id_sport`,
    `paris_2024`.`pays`.`id_pays`         AS `id_pays`,
    `paris_2024`.`equipe`.`id_equipe`     AS `id_equipe`
  FROM ((((`paris_2024`.`athlete`
    JOIN `paris_2024`.`personne`
      ON ((`paris_2024`.`personne`.`id_personne` = `paris_2024`.`athlete`.`id_personne`))) JOIN `paris_2024`.`pays`
      ON ((`paris_2024`.`pays`.`id_pays` = `paris_2024`.`athlete`.`id_pays`))) JOIN `paris_2024`.`sport`
      ON ((`paris_2024`.`sport`.`id_sport` = `paris_2024`.`athlete`.`id_sport`))) LEFT JOIN `paris_2024`.`equipe`
      ON ((`paris_2024`.`athlete`.`id_equipe` = `paris_2024`.`equipe`.`id_equipe`)));

