CREATE VIEW pays_detaille AS
  SELECT
    `paris_2024`.`pays`.`Libelle_pays`     AS `Libelle_pays`,
    `paris_2024`.`pays`.`Description_pays` AS `Description_pays`,
    `paris_2024`.`pays`.`Image_pays`       AS `Image_pays`,
    `paris_2024`.`sport`.`Libelle_sport`   AS `Libelle_sport`,
    `paris_2024`.`personne`.`Nom`          AS `Nom`,
    `paris_2024`.`personne`.`Prenom`       AS `Prenom`
  FROM `paris_2024`.`sport`
    JOIN `paris_2024`.`personne`
    JOIN `paris_2024`.`pays`
    JOIN `paris_2024`.`athlete`
  WHERE ((`paris_2024`.`athlete`.`id_pays` = `paris_2024`.`pays`.`id_pays`) AND
         (`paris_2024`.`athlete`.`id_sport` = `paris_2024`.`sport`.`id_sport`) AND
         (`paris_2024`.`athlete`.`id_personne` = `paris_2024`.`personne`.`id_personne`));

