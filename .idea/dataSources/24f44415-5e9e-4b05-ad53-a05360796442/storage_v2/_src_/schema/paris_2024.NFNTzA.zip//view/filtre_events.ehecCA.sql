CREATE VIEW filtre_events AS
  SELECT
    `paris_2024`.`evenement`.`Photo_evenement`   AS `Photo_evenement`,
    `paris_2024`.`evenement`.`Date_evenement`    AS `Date_evenement`,
    `paris_2024`.`evenement`.`Titre_event`       AS `Titre_event`,
    `paris_2024`.`evenement`.`Description_event` AS `Description_event`,
    `paris_2024`.`evenement`.`id_ville`          AS `id_ville`,
    `paris_2024`.`ville`.`Libelle_ville`         AS `Libelle_ville`,
    `paris_2024`.`lieu`.`Libelle_lieu`           AS `Libelle_lieu`
  FROM `paris_2024`.`evenement`
    JOIN `paris_2024`.`ville`
    JOIN `paris_2024`.`lieu`
  WHERE ((`paris_2024`.`evenement`.`id_ville` = `paris_2024`.`ville`.`id_ville`) AND
         (`paris_2024`.`lieu`.`id_ville` = `paris_2024`.`ville`.`id_ville`));

